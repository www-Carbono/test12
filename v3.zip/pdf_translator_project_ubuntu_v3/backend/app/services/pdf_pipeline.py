from __future__ import annotations

import html
import json
import math
import shutil
import statistics
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import fitz

from app.config import Settings
from app.services.job_store import JobStore
from app.services.translator import OpusTranslator


@dataclass
class TextBlock:
    page_number: int
    bbox: tuple[float, float, float, float]
    text: str
    original_text: str
    font_size: float
    line_height: float
    font_family: str
    raw_font_name: str
    font_weight: str
    font_style: str
    text_align: str
    color: str
    rotation: int = 0
    render_strategy: str = "native-edit"
    background_rgb: tuple[float, float, float] | None = None
    scale_used: float = 1.0


@dataclass
class PageLayout:
    page_number: int
    width: float
    height: float
    strategy: str
    text_blocks: list[TextBlock] = field(default_factory=list)
    image_blocks: int = 0


class PDFTranslationPipeline:
    def __init__(
        self,
        settings: Settings | None = None,
        job_store: JobStore | None = None,
        translator: OpusTranslator | None = None,
    ) -> None:
        self.settings = settings or Settings()
        self.job_store = job_store or JobStore()
        self.translator = translator or OpusTranslator(self.settings)

    def run(self, job_id: str, input_pdf: Path, source_lang: str, target_lang: str, force_ocr: bool) -> Path:
        job_dir = self.job_store.job_dir(job_id)
        searchable_pdf = job_dir / "searchable.pdf"
        structured_json = job_dir / "structured.json"
        translated_json = job_dir / "translated.json"
        final_pdf = job_dir / "translated.pdf"
        snapshots_dir = job_dir / "page_snapshots"
        snapshots_dir.mkdir(parents=True, exist_ok=True)

        self.job_store.update(job_id, status="running")
        self.job_store.append_log(job_id, "Analizando el PDF de entrada.")

        use_ocr = force_ocr or self._needs_ocr(input_pdf)
        self.job_store.update(job_id, auto_ocr_used=use_ocr)

        if use_ocr:
            self.job_store.append_log(job_id, "Aplicando OCR con OCRmyPDF/Tesseract.")
            working_pdf = self._run_ocr(input_pdf, searchable_pdf)
        else:
            shutil.copy2(input_pdf, searchable_pdf)
            working_pdf = searchable_pdf
            self.job_store.append_log(job_id, "PDF con texto nativo detectado; se usará edición directa donde sea posible.")

        self.job_store.append_log(job_id, "Extrayendo layout y cajas de texto con PyMuPDF.")
        pages, stats = self._extract_layout(working_pdf, use_ocr, snapshots_dir)
        structured_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "pages": [self._page_to_dict(page, translated=False) for page in pages],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        self.job_store.update(job_id, stats=stats)

        text_items = [block.text for page in pages for block in page.text_blocks]
        self.job_store.append_log(job_id, f"Traduciendo {len(text_items)} bloques con Marian / OPUS-MT.")
        translated_texts = self.translator.translate_blocks(text_items, source_lang, target_lang)
        self._apply_translations(pages, translated_texts)

        translated_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "pages": [self._page_to_dict(page, translated=True) for page in pages],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        native_pages = sum(1 for page in pages if page.strategy == "native-edit")
        overlay_pages = sum(1 for page in pages if page.strategy == "ocr-overlay")
        self.job_store.append_log(
            job_id,
            f"Reconstruyendo PDF con estrategia híbrida: {native_pages} páginas nativas y {overlay_pages} páginas OCR/overlay.",
        )
        render_stats = self._render_translated_pdf(working_pdf, pages, final_pdf, snapshots_dir)
        stats.update(render_stats)

        self.job_store.update(
            job_id,
            status="completed",
            stats=stats,
            paths={
                "original_pdf": str(input_pdf),
                "searchable_pdf": str(searchable_pdf),
                "structured_json": str(structured_json),
                "translated_json": str(translated_json),
                "translated_pdf": str(final_pdf),
                "page_snapshots_dir": str(snapshots_dir),
            },
        )
        self.job_store.append_log(job_id, "Trabajo completado.")
        return final_pdf

    def _needs_ocr(self, input_pdf: Path) -> bool:
        doc = fitz.open(input_pdf)
        total_chars = 0
        sampled_pages = min(len(doc), 5)
        for page_number in range(sampled_pages):
            page = doc.load_page(page_number)
            text = page.get_text("text")
            total_chars += len(text.strip())
        doc.close()
        avg_chars = total_chars // max(sampled_pages, 1)
        return avg_chars < self.settings.auto_ocr_char_threshold

    def _run_ocr(self, input_pdf: Path, output_pdf: Path) -> Path:
        cmd = [
            "ocrmypdf",
            "--skip-text",
            "--optimize",
            "0",
            str(input_pdf),
            str(output_pdf),
        ]
        process = subprocess.run(cmd, capture_output=True, text=True)
        if process.returncode != 0:
            raise RuntimeError(
                "OCRmyPDF falló. "
                f"stdout={process.stdout.strip()} stderr={process.stderr.strip()}"
            )
        return output_pdf

    def _extract_layout(self, pdf_path: Path, use_ocr: bool, snapshots_dir: Path) -> tuple[list[PageLayout], dict]:
        doc = fitz.open(pdf_path)
        pages: list[PageLayout] = []
        font_sizes: list[float] = []
        image_blocks = 0
        text_blocks = 0
        native_pages = 0
        overlay_pages = 0

        for page_index in range(len(doc)):
            page = doc[page_index]
            strategy = "ocr-overlay" if use_ocr else "native-edit"
            blocks = page.get_text(
                "dict",
                sort=True,
                flags=fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_DEHYPHENATE,
            ).get("blocks", [])
            page_layout = PageLayout(
                page_number=page_index + 1,
                width=float(page.rect.width),
                height=float(page.rect.height),
                strategy=strategy,
            )
            for block in blocks:
                if block.get("type") == 1:
                    page_layout.image_blocks += 1
                    image_blocks += 1
                    continue
                parsed = self._parse_text_block(block, page_layout.width, strategy)
                if parsed is None:
                    continue
                parsed.page_number = page_layout.page_number
                page_layout.text_blocks.append(parsed)
                font_sizes.append(parsed.font_size)
                text_blocks += 1

            if page_layout.text_blocks:
                if page_layout.strategy == "native-edit":
                    native_pages += 1
                elif page_layout.strategy == "ocr-overlay":
                    overlay_pages += 1
            else:
                page_layout.strategy = "passthrough"

            self._save_page_snapshot(page, snapshots_dir / f"page_{page_index + 1:04d}.png")
            pages.append(page_layout)

        doc.close()
        body_size = round(statistics.median(font_sizes), 2) if font_sizes else 10.5
        stats = {
            "pages": len(pages),
            "native_pages": native_pages,
            "ocr_overlay_pages": overlay_pages,
            "passthrough_pages": sum(1 for page in pages if page.strategy == "passthrough"),
            "text_blocks": text_blocks,
            "image_blocks": image_blocks,
            "body_font_size": body_size,
            "layout_mode": "hybrid-direct-pdf",
        }
        return pages, stats

    def _parse_text_block(self, block: dict, page_width: float, strategy: str) -> TextBlock | None:
        bbox = self._normalize_bbox(block.get("bbox", (0, 0, 0, 0)), page_width)
        lines = block.get("lines", [])
        if not lines:
            return None

        rendered_lines: list[str] = []
        font_names: list[str] = []
        sizes: list[float] = []
        colors: list[str] = []
        weights: list[str] = []
        styles: list[str] = []
        line_heights: list[float] = []
        rotations: list[int] = []
        line_lefts: list[float] = []
        line_rights: list[float] = []

        for line in lines:
            spans = line.get("spans", [])
            parts: list[str] = []
            line_bbox = line.get("bbox", bbox)
            line_lefts.append(float(line_bbox[0]))
            line_rights.append(float(line_bbox[2]))
            direction = line.get("dir")
            if direction:
                rotations.append(self._direction_to_rotation(direction))
            if spans:
                line_size = statistics.median([float(span.get("size", 11.0)) for span in spans])
            else:
                line_size = 11.0
            if line_size > 0:
                line_heights.append(max((float(line_bbox[3]) - float(line_bbox[1])) / line_size, 1.0))
            for span in spans:
                text = str(span.get("text", ""))
                if not text:
                    continue
                parts.append(text)
                sizes.append(float(span.get("size", 11.0)))
                font_name = str(span.get("font", "")).strip() or "sans-serif"
                font_names.append(font_name)
                lowered = font_name.lower()
                weights.append("700" if "bold" in lowered or "black" in lowered else "400")
                styles.append("italic" if any(token in lowered for token in ("italic", "oblique")) else "normal")
                colors.append(self._color_to_hex(span.get("color", 0)))
            joined = "".join(parts).rstrip()
            if joined.strip():
                rendered_lines.append(joined)

        text = "\n".join(rendered_lines).strip()
        if not text:
            return None

        font_name = Counter(font_names).most_common(1)[0][0] if font_names else "sans-serif"
        font_size = float(statistics.median(sizes)) if sizes else 11.0
        color = Counter(colors).most_common(1)[0][0] if colors else "#111111"
        font_weight = Counter(weights).most_common(1)[0][0] if weights else "400"
        font_style = Counter(styles).most_common(1)[0][0] if styles else "normal"
        rotation = Counter(rotations).most_common(1)[0][0] if rotations else 0
        line_height = round(min(max(statistics.median(line_heights) if line_heights else 1.18, 1.0), 1.6), 3)
        text_align = self._guess_text_align(line_lefts, line_rights, bbox, page_width)

        return TextBlock(
            page_number=0,
            bbox=bbox,
            text=text,
            original_text=text,
            font_size=font_size,
            line_height=line_height,
            font_family=self._map_font_family(font_name),
            raw_font_name=font_name,
            font_weight=font_weight,
            font_style=font_style,
            text_align=text_align,
            color=color,
            rotation=rotation,
            render_strategy=strategy,
        )

    def _apply_translations(self, pages: list[PageLayout], translated_texts: list[str]) -> None:
        index = 0
        for page in pages:
            for block in page.text_blocks:
                if index < len(translated_texts):
                    block.text = translated_texts[index]
                index += 1

    def _render_translated_pdf(self, working_pdf: Path, pages: list[PageLayout], final_pdf: Path, snapshots_dir: Path) -> dict:
        doc = fitz.open(working_pdf)
        scale_records: list[float] = []
        native_blocks = 0
        overlay_blocks = 0

        for page_layout in pages:
            page = doc[page_layout.page_number - 1]
            if page_layout.strategy == "native-edit":
                self._redact_native_text(page, page_layout.text_blocks)
                for block in page_layout.text_blocks:
                    scale = self._insert_translated_block(page, block)
                    block.scale_used = scale
                    scale_records.append(scale)
                    native_blocks += 1
            elif page_layout.strategy == "ocr-overlay":
                for block in page_layout.text_blocks:
                    block.background_rgb = self._sample_background_rgb(page, block.bbox)
                    self._paint_overlay_background(page, block)
                    scale = self._insert_translated_block(page, block)
                    block.scale_used = scale
                    scale_records.append(scale)
                    overlay_blocks += 1

        save_kwargs = {"garbage": 3, "deflate": True}
        doc.save(str(final_pdf), **save_kwargs)
        doc.close()
        avg_scale = round(statistics.mean(scale_records), 3) if scale_records else 1.0
        return {
            "native_blocks": native_blocks,
            "ocr_overlay_blocks": overlay_blocks,
            "avg_scale_used": f"{avg_scale:.2f}",
        }

    def _redact_native_text(self, page: fitz.Page, blocks: list[TextBlock]) -> None:
        if not blocks:
            return
        for block in blocks:
            rect = self._expand_rect(fitz.Rect(block.bbox), self.settings.overlay_expand_pt * 0.2)
            page.add_redact_annot(rect, fill=None, cross_out=False)
        page.apply_redactions(
            images=fitz.PDF_REDACT_IMAGE_NONE,
            graphics=fitz.PDF_REDACT_LINE_ART_NONE,
            text=fitz.PDF_REDACT_TEXT_REMOVE,
        )

    def _paint_overlay_background(self, page: fitz.Page, block: TextBlock) -> None:
        rect = self._expand_rect(fitz.Rect(block.bbox), self.settings.overlay_expand_pt)
        fill = block.background_rgb or (1.0, 1.0, 1.0)
        shape = page.new_shape()
        shape.draw_rect(rect)
        shape.finish(fill=fill, color=None, fill_opacity=self.settings.ocr_overlay_fill_opacity)
        shape.commit(overlay=True)

    def _insert_translated_block(self, page: fitz.Page, block: TextBlock) -> float:
        rect = self._shrink_rect(fitz.Rect(block.bbox), 0.5)
        if rect.width <= 1 or rect.height <= 1:
            return 1.0

        html_text = self._make_html_fragment(block)
        attempts = [1.0, 0.85, 0.70, 0.55, 0.40, self.settings.htmlbox_min_scale]
        best_scale = 1.0
        success = False
        for allowed_scale in attempts:
            allowed_scale = max(min(allowed_scale, 1.0), self.settings.htmlbox_min_scale)
            spare_height, scale = page.insert_htmlbox(
                rect,
                html_text,
                rotate=block.rotation,
                scale_low=allowed_scale,
                overlay=True,
                opacity=1.0,
            )
            best_scale = scale or best_scale
            if spare_height >= -0.01:
                success = True
                break

        if success:
            return max(min(best_scale, 1.0), 0.01)

        # Fallback defensivo: inserta texto plano aunque sea con una fuente más pequeña.
        align_map = {"left": 0, "center": 1, "right": 2, "justify": 3}
        fontsize = max(self.settings.min_font_size, block.font_size * 0.55)
        page.insert_textbox(
            rect,
            block.text,
            fontsize=fontsize,
            lineheight=block.line_height,
            align=align_map.get(block.text_align, 0),
            rotate=block.rotation,
            color=self._hex_to_rgb(block.color),
            fontname=self._fitz_font_name(block.font_family, block.font_weight, block.font_style),
            overlay=True,
        )
        return max(fontsize / max(block.font_size, 1.0), 0.01)

    def _make_html_fragment(self, block: TextBlock) -> str:
        safe_text = html.escape(block.text).replace("\n", "<br/>")
        font_stack = self._css_font_stack(block.font_family)
        return (
            f'<div style="margin:0;padding:0;font-family:{font_stack};font-size:{block.font_size:.2f}pt;'
            f'line-height:{block.line_height:.3f};font-weight:{block.font_weight};font-style:{block.font_style};'
            f'text-align:{block.text_align};color:{block.color};white-space:pre-wrap;'
            f'overflow-wrap:anywhere;word-break:break-word;hyphens:auto;">{safe_text}</div>'
        )

    def _save_page_snapshot(self, page: fitz.Page, output_path: Path) -> None:
        pix = page.get_pixmap(dpi=self.settings.page_snapshot_dpi, alpha=False)
        pix.save(output_path)

    def _sample_background_rgb(self, page: fitz.Page, bbox: tuple[float, float, float, float]) -> tuple[float, float, float]:
        rect = self._expand_rect(fitz.Rect(bbox), max(self.settings.overlay_expand_pt, 1.0))
        if rect.width <= 2 or rect.height <= 2:
            return (1.0, 1.0, 1.0)
        pix = page.get_pixmap(clip=rect, dpi=96, alpha=False, annots=False)
        width, height, channels = pix.width, pix.height, pix.n
        if width <= 1 or height <= 1 or channels < 3:
            return (1.0, 1.0, 1.0)

        border = max(min(width, height) // 12, 2)
        sample_step = max(min(width, height) // 24, 1)
        samples = memoryview(pix.samples)
        reds: list[int] = []
        greens: list[int] = []
        blues: list[int] = []

        def add_pixel(px: int, py: int) -> None:
            idx = (py * width + px) * channels
            reds.append(samples[idx])
            greens.append(samples[idx + 1])
            blues.append(samples[idx + 2])

        for x in range(0, width, sample_step):
            for y in range(0, border, sample_step):
                add_pixel(x, y)
            for y in range(max(height - border, 0), height, sample_step):
                add_pixel(x, y)
        for y in range(0, height, sample_step):
            for x in range(0, border, sample_step):
                add_pixel(x, y)
            for x in range(max(width - border, 0), width, sample_step):
                add_pixel(x, y)

        if not reds:
            return (1.0, 1.0, 1.0)
        red = statistics.median(reds) / 255.0
        green = statistics.median(greens) / 255.0
        blue = statistics.median(blues) / 255.0
        return (float(red), float(green), float(blue))

    def _page_to_dict(self, page: PageLayout, translated: bool) -> dict:
        return {
            "page_number": page.page_number,
            "width": page.width,
            "height": page.height,
            "strategy": page.strategy,
            "image_blocks": page.image_blocks,
            "text_blocks": [
                {
                    "bbox": list(block.bbox),
                    "text": block.text,
                    "original_text": block.original_text,
                    "font_size": block.font_size,
                    "line_height": block.line_height,
                    "font_family": block.font_family,
                    "raw_font_name": block.raw_font_name,
                    "font_weight": block.font_weight,
                    "font_style": block.font_style,
                    "text_align": block.text_align,
                    "color": block.color,
                    "rotation": block.rotation,
                    "render_strategy": block.render_strategy,
                    "background_rgb": list(block.background_rgb) if block.background_rgb else None,
                    "scale_used": block.scale_used,
                    "translated": translated,
                }
                for block in page.text_blocks
            ],
        }

    def _normalize_bbox(self, bbox: Iterable[float], page_width: float) -> tuple[float, float, float, float]:
        x0, y0, x1, y1 = [float(value) for value in bbox]
        x0 = max(0.0, x0)
        y0 = max(0.0, y0)
        x1 = max(x0 + 0.5, min(x1, page_width))
        y1 = max(y0 + 0.5, y1)
        return (x0, y0, x1, y1)

    def _guess_text_align(
        self,
        line_lefts: list[float],
        line_rights: list[float],
        bbox: tuple[float, float, float, float],
        page_width: float,
    ) -> str:
        if not line_lefts or not line_rights:
            return "left"
        left_spread = max(line_lefts) - min(line_lefts)
        right_spread = max(line_rights) - min(line_rights)
        block_width = max(bbox[2] - bbox[0], 1.0)
        block_center = (bbox[0] + bbox[2]) / 2.0
        page_center = page_width / 2.0
        if abs(block_center - page_center) < page_width * 0.08 and block_width < page_width * 0.7:
            return "center"
        if left_spread < block_width * 0.08 and right_spread < block_width * 0.08 and block_width > page_width * 0.45:
            return "justify"
        if right_spread < block_width * 0.08 and min(line_lefts) > page_width * 0.2:
            return "right"
        return "left"

    def _direction_to_rotation(self, direction: Iterable[float]) -> int:
        dx, dy = list(direction)
        angle = (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0
        candidates = [0, 90, 180, 270]
        closest = min(candidates, key=lambda candidate: min(abs(candidate - angle), abs(candidate - angle + 360), abs(candidate - angle - 360)))
        return int(closest)

    def _map_font_family(self, font_name: str) -> str:
        lowered = (font_name or "").lower()
        if any(token in lowered for token in ("courier", "mono", "console")):
            return "monospace"
        if any(token in lowered for token in ("times", "georgia", "serif", "garamond", "palatino")):
            return "serif"
        return "sans-serif"

    def _css_font_stack(self, font_family: str) -> str:
        if font_family == "monospace":
            return "'Courier New', Courier, monospace"
        if font_family == "serif":
            return "'Times New Roman', Times, serif"
        return "Arial, Helvetica, sans-serif"

    def _fitz_font_name(self, font_family: str, font_weight: str, font_style: str) -> str:
        if font_family == "monospace":
            return "cour"
        if font_family == "serif":
            if font_weight == "700" and font_style == "italic":
                return "tibi"
            if font_weight == "700":
                return "tibo"
            if font_style == "italic":
                return "tiit"
            return "tiro"
        if font_weight == "700" and font_style == "italic":
            return "hebi"
        if font_weight == "700":
            return "hebo"
        if font_style == "italic":
            return "heit"
        return "helv"

    def _expand_rect(self, rect: fitz.Rect, delta: float) -> fitz.Rect:
        return fitz.Rect(rect.x0 - delta, rect.y0 - delta, rect.x1 + delta, rect.y1 + delta)

    def _shrink_rect(self, rect: fitz.Rect, delta: float) -> fitz.Rect:
        if rect.width <= delta * 2 or rect.height <= delta * 2:
            return rect
        return fitz.Rect(rect.x0 + delta, rect.y0 + delta, rect.x1 - delta, rect.y1 - delta)

    def _color_to_hex(self, color_value: int | str | None) -> str:
        if color_value is None:
            return "#111111"
        if isinstance(color_value, str):
            value = color_value.strip()
            if value.startswith("#"):
                return value
            try:
                color_value = int(value)
            except ValueError:
                return "#111111"
        try:
            value = int(color_value)
        except Exception:
            return "#111111"
        if value < 0:
            value = 0
        if value <= 0xFFFFFF:
            return f"#{value:06x}"
        red = (value >> 16) & 255
        green = (value >> 8) & 255
        blue = value & 255
        return f"#{red:02x}{green:02x}{blue:02x}"

    def _hex_to_rgb(self, value: str) -> tuple[float, float, float]:
        value = value.lstrip("#")
        if len(value) != 6:
            return (0.07, 0.07, 0.07)
        red = int(value[0:2], 16) / 255.0
        green = int(value[2:4], 16) / 255.0
        blue = int(value[4:6], 16) / 255.0
        return (red, green, blue)
