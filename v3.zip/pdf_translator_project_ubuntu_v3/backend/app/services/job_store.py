from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.config import JOBS_DIR

_LOCK = threading.RLock()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class JobRecord:
    job_id: str
    source_lang: str
    target_lang: str
    original_filename: str
    status: str = "queued"
    created_at: str = field(default_factory=utc_now_iso)
    updated_at: str = field(default_factory=utc_now_iso)
    force_ocr: bool = False
    auto_ocr_used: bool = False
    log: list[str] = field(default_factory=list)
    error: str | None = None
    paths: dict[str, str] = field(default_factory=dict)
    stats: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "source_lang": self.source_lang,
            "target_lang": self.target_lang,
            "original_filename": self.original_filename,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "force_ocr": self.force_ocr,
            "auto_ocr_used": self.auto_ocr_used,
            "log": self.log,
            "error": self.error,
            "paths": self.paths,
            "stats": self.stats,
        }


class JobStore:
    def __init__(self, base_dir: Path | None = None) -> None:
        self.base_dir = base_dir or JOBS_DIR
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def job_dir(self, job_id: str) -> Path:
        path = self.base_dir / job_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _job_file(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job.json"

    def create(self, source_lang: str, target_lang: str, original_filename: str, force_ocr: bool) -> JobRecord:
        job = JobRecord(
            job_id=str(uuid.uuid4()),
            source_lang=source_lang,
            target_lang=target_lang,
            original_filename=original_filename,
            force_ocr=force_ocr,
        )
        self.save(job)
        return job

    def save(self, job: JobRecord) -> None:
        job.updated_at = utc_now_iso()
        with _LOCK:
            self._job_file(job.job_id).write_text(
                json.dumps(job.to_dict(), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    def load(self, job_id: str) -> JobRecord | None:
        path = self._job_file(job_id)
        if not path.exists():
            return None
        payload = json.loads(path.read_text(encoding="utf-8"))
        return JobRecord(**payload)

    def append_log(self, job_id: str, message: str) -> None:
        with _LOCK:
            job = self.load(job_id)
            if not job:
                return
            job.log.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
            self.save(job)

    def update(self, job_id: str, **updates: Any) -> JobRecord | None:
        with _LOCK:
            job = self.load(job_id)
            if not job:
                return None
            for key, value in updates.items():
                setattr(job, key, value)
            self.save(job)
            return job
