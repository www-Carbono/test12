from __future__ import annotations

import os
import re
import threading
from functools import lru_cache

import torch
from transformers import MarianMTModel, MarianTokenizer

from app.config import Settings, get_model_map

_MODEL_LOCK = threading.Lock()


class TranslationError(RuntimeError):
    pass


class OpusTranslator:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or Settings()
        os.environ.setdefault("HF_HOME", str(self.settings.hf_cache_dir))
        self.model_map = get_model_map(self.settings)
        self.device = torch.device("cpu")

    def model_id_for(self, source_lang: str, target_lang: str) -> str:
        try:
            return self.model_map[(source_lang, target_lang)]
        except KeyError as exc:
            raise TranslationError(
                f"No hay un modelo configurado para {source_lang} → {target_lang}."
            ) from exc

    @lru_cache(maxsize=16)
    def _load_model(self, model_id: str) -> tuple[MarianTokenizer, MarianMTModel]:
        with _MODEL_LOCK:
            tokenizer = MarianTokenizer.from_pretrained(model_id)
            model = MarianMTModel.from_pretrained(model_id)
            model.to(self.device)
            model.eval()
            try:
                model.generation_config.max_length = None
            except Exception:
                pass
            return tokenizer, model

    def translate_blocks(self, texts: list[str], source_lang: str, target_lang: str) -> list[str]:
        model_id = self.model_id_for(source_lang, target_lang)
        tokenizer, model = self._load_model(model_id)
        chunks: list[str] = []
        mapping: list[list[int]] = []

        for text in texts:
            pieces = self._split_text(text)
            if not pieces:
                mapping.append([])
                continue
            idxs = list(range(len(chunks), len(chunks) + len(pieces)))
            mapping.append(idxs)
            chunks.extend(pieces)

        if not chunks:
            return texts

        translated_chunks: list[str] = []
        batch_size = max(1, self.settings.translation_batch_size)

        for start in range(0, len(chunks), batch_size):
            batch = chunks[start : start + batch_size]
            encoded = tokenizer(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
            )
            encoded = {key: value.to(self.device) for key, value in encoded.items()}
            with torch.no_grad():
                generated = model.generate(
                    **encoded,
                    max_new_tokens=self.settings.max_new_tokens,
                    num_beams=1,
                )
            translated_chunks.extend(tokenizer.batch_decode(generated, skip_special_tokens=True))

        rebuilt: list[str] = []
        for original, indexes in zip(texts, mapping):
            if not indexes:
                rebuilt.append(original)
                continue
            pieces = [translated_chunks[idx].strip() for idx in indexes]
            rebuilt.append(self._rejoin_pieces(pieces, original))
        return rebuilt

    def _split_text(self, text: str) -> list[str]:
        cleaned = re.sub(r"\s+", " ", text).strip()
        if not cleaned:
            return []
        chunk_size = max(80, self.settings.translation_char_chunk)
        if len(cleaned) <= chunk_size:
            return [cleaned]

        sentences = re.split(r"(?<=[\.!?;:])\s+", cleaned)
        chunks: list[str] = []
        current = ""
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            candidate = sentence if not current else f"{current} {sentence}"
            if len(candidate) <= chunk_size:
                current = candidate
                continue
            if current:
                chunks.append(current)
            if len(sentence) <= chunk_size:
                current = sentence
            else:
                chunks.extend(sentence[i : i + chunk_size] for i in range(0, len(sentence), chunk_size))
                current = ""
        if current:
            chunks.append(current)
        return chunks

    def _rejoin_pieces(self, pieces: list[str], original: str) -> str:
        if not pieces:
            return original
        line_breaks = original.count("\n")
        if line_breaks <= 0:
            return " ".join(piece for piece in pieces if piece).strip()
        joined = " ".join(piece for piece in pieces if piece).strip()
        words = joined.split()
        if not words:
            return joined
        target_lines = line_breaks + 1
        approx_words_per_line = max(round(len(words) / target_lines), 1)
        lines: list[str] = []
        for index in range(0, len(words), approx_words_per_line):
            lines.append(" ".join(words[index : index + approx_words_per_line]))
        return "\n".join(lines)
