# PDF Translator Pipeline (Ubuntu, fidelity-first v3)

Proyecto completo para traducir PDF con este pipeline base:

**PyMuPDF + OCRmyPDF/Tesseract + Marian / OPUS-MT por par de idiomas**

La v3 cambia el enfoque de render para acercarse mucho más al original:

- si la página tiene **texto nativo**, conserva la página original y elimina solo el texto, para volver a escribir la traducción dentro de las mismas cajas;
- si la página viene de **OCR / escaneo**, mantiene el fondo original y superpone la traducción con parches de color aproximado.

WeasyPrint sigue instalado como dependencia útil de depuración/preview, pero el PDF final de v3 se genera directamente con **PyMuPDF** porque así la fidelidad visual es bastante mejor.

## Qué mejora esta versión

1. Conserva mucho mejor gráficos, imágenes, fondos y elementos vectoriales.
2. Mantiene la caja real de cada página del PDF original.
3. Reemplaza solo el texto cuando existe una capa nativa editable.
4. En OCR, cubre el texto antiguo con parches de fondo y escribe encima la traducción.
5. Guarda JSON estructurado, traducciones y capturas de página para depurar mejor.

## Arquitectura

```text
PDF entrada
  └─ detección OCR
      ├─ nativo: edición directa del PDF original
      └─ OCR/escaneado: overlay sobre la página original
          └─ traducción por bloques con Marian / OPUS-MT
```

## Instalación rápida en Ubuntu

```bash
cd pdf_translator_project_ubuntu_v3
bash scripts/install_ubuntu.sh
source .venv/bin/activate
cp .env.example .env
bash scripts/run.sh
```

Abre luego:

- local: `http://localhost:8000`
- remoto: `http://IP_DEL_SERVIDOR:8000`

## Precargar modelos

No es obligatorio. La primera traducción descarga el modelo al primer uso.
Si prefieres dejarlo listo antes:

```bash
source .venv/bin/activate
python scripts/prefetch_models.py
```

## Variables útiles de `.env`

```env
APP_HOST=0.0.0.0
APP_PORT=8000
MAX_UPLOAD_MB=80
AUTO_OCR_CHAR_THRESHOLD=60
TRANSLATION_BATCH_SIZE=8
TRANSLATION_CHAR_CHUNK=450
TRANSLATION_MAX_NEW_TOKENS=512
LAYOUT_MIN_FONT_SIZE=6.0
HTMLBOX_MIN_SCALE=0.20
OVERLAY_EXPAND_PT=0.75
OCR_OVERLAY_FILL_OPACITY=0.98
PAGE_SNAPSHOT_DPI=150
MODEL_MAP_FILE=config/custom_models.json
HF_HOME=.cache/huggingface
```

## Cómo decide el render

### 1) Página nativa

Se usa cuando el PDF ya tiene texto real suficiente.

Pasos:
- extraer cajas de texto y estilo con PyMuPDF
- traducir por bloques
- redacción sin relleno para eliminar solo el texto original
- insertar traducción dentro del mismo rectángulo

### 2) Página OCR / escaneada

Se usa cuando el documento necesita OCR o lo fuerzas desde la interfaz.

Pasos:
- OCRmyPDF genera un PDF searchable
- se conserva la página original
- para cada bloque se estima el color de fondo alrededor del texto
- se pinta un parche sobre el texto antiguo
- se inserta la traducción encima

## Salidas por trabajo

Cada trabajo se guarda en:

```text
backend/data/jobs/<job_id>/
```

Y genera como mínimo:

- `searchable.pdf`
- `structured.json`
- `translated.json`
- `translated.pdf`
- `page_snapshots/` con capturas PNG de páginas para depuración

## Limitaciones honestas

- En PDFs muy complejos con texto curvado, texto dentro de diagramas o rotaciones raras, puede seguir habiendo diferencias.
- En escaneados, la fidelidad nunca será igual a un PDF nativo porque el texto original forma parte de la imagen.
- Si la traducción crece mucho, el bloque puede reducir la fuente para encajar.

## Recomendación práctica

- Para manuales, facturas, contratos y documentación nativa: esta v3 debería acercarse mucho más al original que v1/v2.
- Para PDFs escaneados: mejora bastante, pero el límite real lo marca la calidad del OCR y del escaneo.
