#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"

sudo apt-get update
sudo apt-get install -y   python3 python3-venv python3-pip build-essential   tesseract-ocr tesseract-ocr-eng tesseract-ocr-spa tesseract-ocr-fra tesseract-ocr-deu tesseract-ocr-ita tesseract-ocr-por   ghostscript pngquant qpdf   libcairo2 libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf-2.0-0 libffi-dev shared-mime-info fonts-dejavu-core

cd "$PROJECT_ROOT"
$PYTHON_BIN -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools
pip install -r requirements.txt

cp -n .env.example .env || true

cat <<'EOF'

Instalación base completada.

Siguientes pasos:
1. Activa el entorno: source .venv/bin/activate
2. (Opcional) Precarga modelos: python scripts/prefetch_models.py
3. Arranca la app: uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000
4. Abre: http://localhost:8000
EOF
