#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

if [[ -f .venv/bin/activate ]]; then
  source .venv/bin/activate
fi

set -a
[[ -f .env ]] && source .env
set +a

uvicorn app.main:app --app-dir backend --host "${APP_HOST:-0.0.0.0}" --port "${APP_PORT:-8000}"
