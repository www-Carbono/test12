from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "backend"))

from app.config import Settings, list_supported_pairs  # noqa: E402
from app.services.translator import OpusTranslator  # noqa: E402


def main() -> None:
    settings = Settings()
    translator = OpusTranslator(settings)
    pairs = list_supported_pairs(settings)
    print(f"Descargando {len(pairs)} pares configurados...")
    for pair in pairs:
        model_id = translator.model_id_for(pair['source'], pair['target'])
        print(f"- {pair['label']} => {model_id}")
        translator._load_model(model_id)
    print("Hecho.")


if __name__ == "__main__":
    main()
