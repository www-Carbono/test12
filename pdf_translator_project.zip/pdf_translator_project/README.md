# PDF Translator Pipeline (self-hosted)

Proyecto completo para traducir PDF con este pipeline:

**PyMuPDF + OCRmyPDF/Tesseract + Marian / OPUS-MT por par de idiomas + WeasyPrint**

Incluye:

- Backend con **FastAPI**
- Frontend simple con subida de PDF y seguimiento del trabajo
- OCR automático o forzado
- Traducción local con modelos **Helsinki-NLP/opus-mt-*** vía `transformers`
- Reconstrucción del resultado a HTML y PDF con **WeasyPrint**
- Cola básica por trabajos con almacenamiento local

## Estructura

```text
pdf_translator_project/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── templates/index.html
│   │   ├── static/css/styles.css
│   │   ├── static/js/app.js
│   │   └── services/
│   │       ├── job_store.py
│   │       ├── pdf_pipeline.py
│   │       └── translator.py
│   └── data/
├── config/
│   └── custom_models.json
├── scripts/
│   ├── install_ubuntu.sh
│   ├── prefetch_models.py
│   └── run.sh
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

## Qué hace exactamente

1. Recibe un PDF desde la web.
2. Detecta si hace falta OCR. También puedes forzarlo manualmente.
3. Si hace falta OCR, genera una versión searchable del PDF con `ocrmypdf`.
4. Extrae bloques de texto con **PyMuPDF**.
5. Traduce esos bloques con un modelo **OPUS-MT / Marian** por par de idiomas.
6. Reconstruye el documento en HTML.
7. Genera un nuevo PDF con **WeasyPrint**.

## Limitación importante

Este proyecto prioriza un pipeline robusto y fácil de mantener. El PDF final es **reconstruido**, no clonado pixel a pixel. En documentos muy complejos puede cambiar el flujo del texto, aunque normalmente el resultado es más estable que intentar posicionar cada bloque exactamente.

## Instalación rápida en Ubuntu

### 1) Instala el proyecto

```bash
cd pdf_translator_project
bash scripts/install_ubuntu.sh
```

### 2) Activa el entorno virtual

```bash
source .venv/bin/activate
```

### 3) Copia la configuración base

```bash
cp .env.example .env
```

### 4) Arranca la aplicación

```bash
bash scripts/run.sh
```

### 5) Abre la web

```text
http://localhost:8000
```

## Precargar modelos

La primera traducción descarga el modelo automáticamente. Si prefieres dejarlo preparado antes:

```bash
source .venv/bin/activate
python scripts/prefetch_models.py
```

## Cambiar o ampliar pares de idiomas

Edita `config/custom_models.json`.

Ejemplo:

```json
[
  {
    "source": "es",
    "target": "en",
    "model_id": "Helsinki-NLP/opus-mt-es-en"
  },
  {
    "source": "en",
    "target": "fr",
    "model_id": "Helsinki-NLP/opus-mt-en-fr"
  }
]
```

Después reinicia la app.

## Ejecución sin script

```bash
source .venv/bin/activate
uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000
```

## Docker

### Levantar con Docker Compose

```bash
docker compose up --build
```

Esto deja la app en:

```text
http://localhost:8000
```

## Dependencias del sistema que necesitas

- `tesseract-ocr`
- `ghostscript`
- `qpdf`
- `pngquant`
- Librerías de Cairo/Pango para WeasyPrint

El script `scripts/install_ubuntu.sh` ya instala todo eso.

## Formato de salida y artefactos generados

Cada trabajo guarda:

- PDF original
- PDF con OCR/searchable
- JSON estructurado extraído
- JSON con bloques traducidos
- HTML reconstruido
- PDF final traducido

Todo queda dentro de `backend/data/jobs/<job_id>/`.

## Recomendaciones prácticas

- Para PDFs escaneados, marca **Forzar OCR** si el detector automático no acierta.
- Para VPS pequeños, reduce el número de pares configurados.
- Precargar demasiados modelos ocupa disco y retrasa despliegues.
- Si tu caso principal es un solo par de idiomas, deja solo ese modelo en la configuración.

## Posibles mejoras futuras

- Cola con Redis/Celery
- OCR por idioma configurable desde la UI
- Perfiles de reconstrucción (fiel vs reflow)
- Preservación más avanzada de tablas
- Autenticación y límite de tamaño por usuario

## Licencias y modelos

Este proyecto usa modelos OPUS-MT alojados en Hugging Face. Revisa la licencia del modelo concreto que vayas a activar para producción.
