from __future__ import annotations

import shutil
import threading
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import STATIC_DIR, TEMPLATES_DIR, UPLOADS_DIR, Settings, list_supported_pairs, get_model_map
from app.services.job_store import JobStore
from app.services.pdf_pipeline import PDFTranslationPipeline
from app.services.translator import OpusTranslator

settings = Settings()
job_store = JobStore()
translator = OpusTranslator(settings)
pipeline = PDFTranslationPipeline(settings=settings, job_store=job_store, translator=translator)

app = FastAPI(title="PDF Translator", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def _start_job_thread(job_id: str, input_pdf: Path, source_lang: str, target_lang: str, force_ocr: bool) -> None:
    def runner() -> None:
        try:
            pipeline.run(job_id, input_pdf, source_lang, target_lang, force_ocr)
        except Exception as exc:  # noqa: BLE001
            job_store.append_log(job_id, f"Error: {exc}")
            job_store.update(job_id, status="failed", error=str(exc))

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "pairs": list_supported_pairs(settings),
            "max_upload_mb": settings.max_upload_mb,
        },
    )


@app.get("/api/config")
def get_config() -> dict:
    return {
        "supported_pairs": list_supported_pairs(settings),
        "max_upload_mb": settings.max_upload_mb,
    }


@app.post("/api/jobs")
async def create_job(
    pdf_file: UploadFile = File(...),
    source_lang: str = Form(...),
    target_lang: str = Form(...),
    force_ocr: bool = Form(False),
) -> JSONResponse:
    if pdf_file.content_type not in {"application/pdf", "application/octet-stream"}:
        raise HTTPException(status_code=400, detail="Solo se aceptan archivos PDF.")

    model_map = get_model_map(settings)
    if (source_lang, target_lang) not in model_map:
        raise HTTPException(status_code=400, detail="Par de idiomas no configurado.")

    payload = await pdf_file.read()
    size_mb = len(payload) / (1024 * 1024)
    if size_mb > settings.max_upload_mb:
        raise HTTPException(status_code=413, detail=f"El archivo supera el límite de {settings.max_upload_mb} MB.")

    job = job_store.create(
        source_lang=source_lang,
        target_lang=target_lang,
        original_filename=pdf_file.filename or "document.pdf",
        force_ocr=bool(force_ocr),
    )
    upload_path = UPLOADS_DIR / f"{job.job_id}.pdf"
    upload_path.write_bytes(payload)
    job.paths["original_pdf"] = str(upload_path)
    job_store.save(job)
    job_store.append_log(job.job_id, f"Archivo recibido: {pdf_file.filename}")
    _start_job_thread(job.job_id, upload_path, source_lang, target_lang, bool(force_ocr))
    return JSONResponse({"job_id": job.job_id, "status": job.status})


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> JSONResponse:
    job = job_store.load(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Trabajo no encontrado.")
    return JSONResponse(job.to_dict())


@app.get("/api/jobs/{job_id}/download")
def download_job(job_id: str) -> FileResponse:
    job = job_store.load(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Trabajo no encontrado.")
    if job.status != "completed":
        raise HTTPException(status_code=409, detail="El trabajo aún no ha terminado.")
    output_path = Path(job.paths["translated_pdf"])
    if not output_path.exists():
        raise HTTPException(status_code=404, detail="No se encontró el PDF traducido.")
    output_name = Path(job.original_filename).stem + f"_{job.target_lang}.pdf"
    return FileResponse(path=output_path, filename=output_name, media_type="application/pdf")


@app.get("/health")
def health() -> dict:
    return {"ok": True}
