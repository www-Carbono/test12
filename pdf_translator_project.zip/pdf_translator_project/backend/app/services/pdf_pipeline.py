from __future__ import annotations

import html
import json
import shutil
import statistics
import subprocess
from dataclasses import dataclass
from pathlib import Path

import fitz
from weasyprint import HTML

from app.config import Settings
from app.services.job_store import JobStore
from app.services.translator import OpusTranslator


@dataclass
class TextBlock:
    page_number: int
    text: str
    font_size: float
    is_heading: bool


class PDFTranslationPipeline:
    def __init__(
        self,
        settings: Settings | None = None,
        job_store: JobStore | None = None,
        translator: OpusTranslator | None = None,
    ) -> None:
        self.settings = settings or Settings()
        self.job_store = job_store or JobStore()
        self.translator = translator or OpusTranslator(self.settings)

    def run(self, job_id: str, input_pdf: Path, source_lang: str, target_lang: str, force_ocr: bool) -> Path:
        job_dir = self.job_store.job_dir(job_id)
        searchable_pdf = job_dir / "searchable.pdf"
        structured_json = job_dir / "structured.json"
        translated_json = job_dir / "translated.json"
        html_out = job_dir / "translated.html"
        final_pdf = job_dir / "translated.pdf"

        self.job_store.update(job_id, status="running")
        self.job_store.append_log(job_id, "Analizando el PDF de entrada.")

        use_ocr = force_ocr or self._needs_ocr(input_pdf)
        self.job_store.update(job_id, auto_ocr_used=use_ocr)

        working_pdf = input_pdf
        if use_ocr:
            self.job_store.append_log(job_id, "Aplicando OCR con OCRmyPDF/Tesseract.")
            working_pdf = self._run_ocr(input_pdf, searchable_pdf)
        else:
            shutil.copy2(input_pdf, searchable_pdf)
            working_pdf = searchable_pdf
            self.job_store.append_log(job_id, "No se detectó OCR obligatorio; se usa el PDF original.")

        self.job_store.append_log(job_id, "Extrayendo bloques de texto con PyMuPDF.")
        blocks, stats = self._extract_blocks(working_pdf)
        structured_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "blocks": [block.__dict__ for block in blocks],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        self.job_store.update(job_id, stats=stats)

        self.job_store.append_log(job_id, "Traduciendo bloques con Marian / OPUS-MT.")
        translated_texts = self.translator.translate_blocks([block.text for block in blocks], source_lang, target_lang)
        translated_blocks = [
            TextBlock(
                page_number=block.page_number,
                text=translated_text,
                font_size=block.font_size,
                is_heading=block.is_heading,
            )
            for block, translated_text in zip(blocks, translated_texts)
        ]
        translated_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "blocks": [block.__dict__ for block in translated_blocks],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        self.job_store.append_log(job_id, "Reconstruyendo HTML para WeasyPrint.")
        html_string = self._build_html(translated_blocks, source_lang, target_lang, input_pdf.name)
        html_out.write_text(html_string, encoding="utf-8")

        self.job_store.append_log(job_id, "Generando PDF final con WeasyPrint.")
        HTML(string=html_string, base_url=str(job_dir)).write_pdf(str(final_pdf))

        self.job_store.update(
            job_id,
            status="completed",
            paths={
                "original_pdf": str(input_pdf),
                "searchable_pdf": str(searchable_pdf),
                "structured_json": str(structured_json),
                "translated_json": str(translated_json),
                "translated_html": str(html_out),
                "translated_pdf": str(final_pdf),
            },
        )
        self.job_store.append_log(job_id, "Trabajo completado.")
        return final_pdf

    def _needs_ocr(self, input_pdf: Path) -> bool:
        doc = fitz.open(input_pdf)
        total_chars = 0
        sampled_pages = min(len(doc), 5)
        for page_number in range(sampled_pages):
            page = doc.load_page(page_number)
            text = page.get_text("text")
            total_chars += len(text.strip())
        doc.close()
        avg_chars = total_chars // max(sampled_pages, 1)
        return avg_chars < self.settings.auto_ocr_char_threshold

    def _run_ocr(self, input_pdf: Path, output_pdf: Path) -> Path:
        cmd = [
            "ocrmypdf",
            "--skip-text",
            "--optimize",
            "0",
            str(input_pdf),
            str(output_pdf),
        ]
        process = subprocess.run(cmd, capture_output=True, text=True)
        if process.returncode != 0:
            raise RuntimeError(
                "OCRmyPDF falló. "
                f"stdout={process.stdout.strip()} stderr={process.stderr.strip()}"
            )
        return output_pdf

    def _extract_blocks(self, pdf_path: Path) -> tuple[list[TextBlock], dict]:
        doc = fitz.open(pdf_path)
        extracted: list[dict] = []
        font_sizes: list[float] = []
        pages_with_text = 0

        for page_index in range(len(doc)):
            page = doc.load_page(page_index)
            blocks = page.get_text("dict", sort=True).get("blocks", [])
            page_had_text = False
            for block in blocks:
                if block.get("type") != 0:
                    continue
                lines = block.get("lines", [])
                texts: list[str] = []
                local_sizes: list[float] = []
                for line in lines:
                    line_text_parts: list[str] = []
                    for span in line.get("spans", []):
                        span_text = span.get("text", "")
                        if not span_text.strip():
                            continue
                        line_text_parts.append(span_text)
                        local_sizes.append(float(span.get("size", 11.0)))
                    joined_line = " ".join(part.strip() for part in line_text_parts if part.strip())
                    if joined_line:
                        texts.append(joined_line)
                text = "\n".join(texts).strip()
                if not text:
                    continue
                page_had_text = True
                font_size = statistics.median(local_sizes) if local_sizes else 11.0
                extracted.append(
                    {
                        "page_number": page_index + 1,
                        "text": text,
                        "font_size": float(font_size),
                    }
                )
                font_sizes.extend(local_sizes)
            if page_had_text:
                pages_with_text += 1
        doc.close()

        body_size = statistics.median(font_sizes) if font_sizes else 11.0
        out_blocks = [
            TextBlock(
                page_number=item["page_number"],
                text=item["text"],
                font_size=item["font_size"],
                is_heading=item["font_size"] >= body_size * 1.18 and len(item["text"]) < 180,
            )
            for item in extracted
        ]
        stats = {
            "pages": max((block.page_number for block in out_blocks), default=0),
            "blocks": len(out_blocks),
            "pages_with_text": pages_with_text,
            "body_font_size": round(body_size, 2),
        }
        return out_blocks, stats

    def _build_html(
        self,
        blocks: list[TextBlock],
        source_lang: str,
        target_lang: str,
        original_filename: str,
    ) -> str:
        grouped: dict[int, list[TextBlock]] = {}
        for block in blocks:
            grouped.setdefault(block.page_number, []).append(block)

        pages_html: list[str] = []
        for page_number in sorted(grouped):
            inner_parts = [f'<div class="page-meta">Página {page_number}</div>']
            for block in grouped[page_number]:
                safe_text = html.escape(block.text).replace("\n", "<br>")
                if block.is_heading:
                    inner_parts.append(f"<h2>{safe_text}</h2>")
                else:
                    inner_parts.append(f"<p>{safe_text}</p>")
            pages_html.append(f'<section class="page">{"".join(inner_parts)}</section>')

        return f"""
<!doctype html>
<html lang=\"es\">
<head>
  <meta charset=\"utf-8\">
  <title>PDF traducido</title>
  <style>
    @page {{
      size: A4;
      margin: 18mm 16mm 18mm 16mm;
    }}
    * {{ box-sizing: border-box; }}
    html, body {{ font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #111827; }}
    body {{ margin: 0; font-size: 11pt; line-height: 1.45; }}
    header {{ border-bottom: 1px solid #d1d5db; padding-bottom: 12px; margin-bottom: 18px; }}
    header h1 {{ margin: 0 0 6px; font-size: 18pt; }}
    header p {{ margin: 0; color: #4b5563; }}
    .page {{ page-break-after: always; }}
    .page:last-child {{ page-break-after: auto; }}
    .page-meta {{ font-size: 9pt; color: #6b7280; margin-bottom: 10px; text-transform: uppercase; letter-spacing: .08em; }}
    h2 {{ margin: 16px 0 8px; font-size: 15pt; line-height: 1.2; }}
    p {{ margin: 0 0 10px; text-align: justify; white-space: normal; }}
    .cover {{ margin-bottom: 12px; }}
    .cover strong {{ display: inline-block; min-width: 140px; }}
  </style>
</head>
<body>
  <header>
    <h1>PDF traducido</h1>
    <p>Este PDF se reconstruyó con un pipeline local: PyMuPDF + OCRmyPDF/Tesseract + Marian / OPUS-MT + WeasyPrint.</p>
  </header>
  <section class=\"cover\">
    <p><strong>Archivo original:</strong> {html.escape(original_filename)}</p>
    <p><strong>Idioma origen:</strong> {html.escape(source_lang)}</p>
    <p><strong>Idioma destino:</strong> {html.escape(target_lang)}</p>
  </section>
  {''.join(pages_html)}
</body>
</html>
""".strip()
