from __future__ import annotations

import os
import re
import threading
from functools import lru_cache
from typing import Iterable

import torch
from transformers import MarianMTModel, MarianTokenizer

from app.config import Settings, get_model_map

_MODEL_LOCK = threading.Lock()


class TranslationError(RuntimeError):
    pass


class OpusTranslator:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or Settings()
        os.environ.setdefault("HF_HOME", str(self.settings.hf_cache_dir))
        self.model_map = get_model_map(self.settings)
        self.device = torch.device("cpu")

    def model_id_for(self, source_lang: str, target_lang: str) -> str:
        try:
            return self.model_map[(source_lang, target_lang)]
        except KeyError as exc:
            raise TranslationError(
                f"No hay un modelo configurado para {source_lang} → {target_lang}."
            ) from exc

    @lru_cache(maxsize=16)
    def _load_model(self, model_id: str) -> tuple[MarianTokenizer, MarianMTModel]:
        with _MODEL_LOCK:
            tokenizer = MarianTokenizer.from_pretrained(model_id)
            model = MarianMTModel.from_pretrained(model_id)
            model.to(self.device)
            model.eval()
            return tokenizer, model

    def translate_blocks(self, texts: list[str], source_lang: str, target_lang: str) -> list[str]:
        model_id = self.model_id_for(source_lang, target_lang)
        tokenizer, model = self._load_model(model_id)
        chunks: list[str] = []
        mapping: list[list[int]] = []

        for text in texts:
            pieces = self._split_text(text)
            if not pieces:
                mapping.append([])
                continue
            idxs = list(range(len(chunks), len(chunks) + len(pieces)))
            mapping.append(idxs)
            chunks.extend(pieces)

        if not chunks:
            return texts

        translated_chunks: list[str] = []
        batch_size = self.settings.translation_batch_size

        for i in range(0, len(chunks), batch_size):
            batch = chunks[i : i + batch_size]
            encoded = tokenizer(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=512,
            )
            encoded = {key: value.to(self.device) for key, value in encoded.items()}
            with torch.no_grad():
                generated = model.generate(
                    **encoded,
                    max_new_tokens=self.settings.max_new_tokens,
                    num_beams=1,
                )
            decoded = tokenizer.batch_decode(generated, skip_special_tokens=True)
            translated_chunks.extend(decoded)

        out: list[str] = []
        for original, idxs in zip(texts, mapping):
            if not idxs:
                out.append(original)
                continue
            merged = " ".join(translated_chunks[idx] for idx in idxs)
            out.append(self._normalize_spacing(merged))
        return out

    def _split_text(self, text: str) -> list[str]:
        text = self._normalize_spacing(text)
        if not text:
            return []

        max_chars = self.settings.translation_char_chunk
        if len(text) <= max_chars:
            return [text]

        sentences = re.split(r"(?<=[.!?;:])\s+", text)
        pieces: list[str] = []
        buffer = ""
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            candidate = f"{buffer} {sentence}".strip() if buffer else sentence
            if len(candidate) <= max_chars:
                buffer = candidate
            else:
                if buffer:
                    pieces.append(buffer)
                if len(sentence) <= max_chars:
                    buffer = sentence
                else:
                    pieces.extend(self._split_hard(sentence, max_chars))
                    buffer = ""
        if buffer:
            pieces.append(buffer)
        return pieces

    @staticmethod
    def _split_hard(text: str, max_chars: int) -> Iterable[str]:
        words = text.split()
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip() if current else word
            if len(candidate) <= max_chars:
                current = candidate
            else:
                if current:
                    yield current
                current = word
        if current:
            yield current

    @staticmethod
    def _normalize_spacing(text: str) -> str:
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()
