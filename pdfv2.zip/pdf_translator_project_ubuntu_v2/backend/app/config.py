from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Tuple

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "backend" / "data"
JOBS_DIR = DATA_DIR / "jobs"
UPLOADS_DIR = DATA_DIR / "uploads"
OUTPUT_DIR = DATA_DIR / "output"
TEMPLATES_DIR = BASE_DIR / "backend" / "app" / "templates"
STATIC_DIR = BASE_DIR / "backend" / "app" / "static"
MODELS_DIR = BASE_DIR / "models"

for path in (DATA_DIR, JOBS_DIR, UPLOADS_DIR, OUTPUT_DIR, MODELS_DIR):
    path.mkdir(parents=True, exist_ok=True)


DEFAULT_MODEL_MAP: Dict[Tuple[str, str], str] = {
    ("es", "en"): "Helsinki-NLP/opus-mt-es-en",
    ("en", "es"): "Helsinki-NLP/opus-mt-en-es",
    ("fr", "en"): "Helsinki-NLP/opus-mt-fr-en",
    ("en", "fr"): "Helsinki-NLP/opus-mt-en-fr",
    ("de", "en"): "Helsinki-NLP/opus-mt-de-en",
    ("en", "de"): "Helsinki-NLP/opus-mt-en-de",
    ("it", "en"): "Helsinki-NLP/opus-mt-it-en",
    ("en", "it"): "Helsinki-NLP/opus-mt-en-it",
    ("pt", "en"): "Helsinki-NLP/opus-mt-ROMANCE-en",
    ("en", "pt"): "Helsinki-NLP/opus-mt-en-ROMANCE",
    ("ca", "en"): "Helsinki-NLP/opus-mt-ca-en",
    ("en", "ca"): "Helsinki-NLP/opus-mt-en-ca",
    ("gl", "en"): "Helsinki-NLP/opus-mt-ROMANCE-en",
    ("en", "gl"): "Helsinki-NLP/opus-mt-en-ROMANCE",
    ("es", "fr"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("fr", "es"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("es", "it"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("it", "es"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("es", "pt"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("pt", "es"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("fr", "it"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("it", "fr"): "Helsinki-NLP/opus-mt-ROMANCE-ROMANCE",
    ("de", "es"): "Helsinki-NLP/opus-mt-de-es",
    ("es", "de"): "Helsinki-NLP/opus-mt-es-de",
}

LANGUAGE_NAMES = {
    "es": "Español",
    "en": "Inglés",
    "fr": "Francés",
    "de": "Alemán",
    "it": "Italiano",
    "pt": "Portugués",
    "ca": "Catalán",
    "gl": "Gallego",
}


@dataclass(frozen=True)
class Settings:
    host: str = os.getenv("APP_HOST", "0.0.0.0")
    port: int = int(os.getenv("APP_PORT", "8000"))
    workers: int = int(os.getenv("APP_WORKERS", "1"))
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "80"))
    auto_ocr_char_threshold: int = int(os.getenv("AUTO_OCR_CHAR_THRESHOLD", "60"))
    hf_cache_dir: Path = Path(os.getenv("HF_HOME", str(BASE_DIR / ".cache" / "huggingface")))
    translation_batch_size: int = int(os.getenv("TRANSLATION_BATCH_SIZE", "8"))
    translation_char_chunk: int = int(os.getenv("TRANSLATION_CHAR_CHUNK", "450"))
    max_new_tokens: int = int(os.getenv("TRANSLATION_MAX_NEW_TOKENS", "512"))
    min_font_size: float = float(os.getenv("LAYOUT_MIN_FONT_SIZE", "6.5"))
    model_map_file: Path | None = (
        Path(os.getenv("MODEL_MAP_FILE")) if os.getenv("MODEL_MAP_FILE") else None
    )


def _load_external_model_map(path: Path) -> Dict[Tuple[str, str], str]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    result: Dict[Tuple[str, str], str] = {}
    for item in payload:
        result[(item["source"], item["target"])] = item["model_id"]
    return result


def get_model_map(settings: Settings | None = None) -> Dict[Tuple[str, str], str]:
    settings = settings or Settings()
    model_map = DEFAULT_MODEL_MAP.copy()
    if settings.model_map_file and settings.model_map_file.exists():
        model_map.update(_load_external_model_map(settings.model_map_file))
    return model_map


def list_supported_pairs(settings: Settings | None = None) -> list[dict]:
    model_map = get_model_map(settings)
    pairs = []
    for (source, target), model_id in sorted(model_map.items()):
        pairs.append(
            {
                "source": source,
                "target": target,
                "label": f"{LANGUAGE_NAMES.get(source, source)} → {LANGUAGE_NAMES.get(target, target)}",
                "model_id": model_id,
            }
        )
    return pairs
