const form = document.getElementById('upload-form');
const sourceSelect = document.getElementById('source_lang');
const targetSelect = document.getElementById('target_lang');
const jobPanel = document.getElementById('job-panel');
const downloadPanel = document.getElementById('download-panel');
const pairs = window.APP_CONFIG.pairs || [];

function uniqueLanguages(side) {
  const map = new Map();
  pairs.forEach(pair => {
    const code = pair[side];
    const label = side === 'source' ? pair.label.split(' → ')[0] : pair.label.split(' → ')[1];
    map.set(code, `${code.toUpperCase()} - ${label}`);
  });
  return Array.from(map.entries()).sort((a, b) => a[1].localeCompare(b[1]));
}

function fillLanguageSelect(select, entries, selectedValue) {
  select.innerHTML = '';
  entries.forEach(([code, label]) => {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = label;
    if (code === selectedValue) option.selected = true;
    select.appendChild(option);
  });
}

function syncTargetOptions() {
  const source = sourceSelect.value;
  const targets = pairs
    .filter(pair => pair.source === source)
    .map(pair => [pair.target, `${pair.target.toUpperCase()} - ${pair.label.split(' → ')[1]}`]);
  const previousTarget = targetSelect.value;
  fillLanguageSelect(targetSelect, targets, previousTarget);
  if (!targetSelect.value && targets.length) {
    targetSelect.value = targets[0][0];
  }
}

function renderStatus(job) {
  const statusClass = ['running', 'completed', 'failed'].includes(job.status) ? job.status : '';
  const stats = job.stats || {};
  const statsHtml = Object.keys(stats).length
    ? `
      <div class="stats-grid">
        <p><strong>Páginas:</strong> ${stats.pages || 0}</p>
        <p><strong>Bloques texto:</strong> ${stats.text_blocks || 0}</p>
        <p><strong>Imágenes:</strong> ${stats.image_blocks || 0}</p>
        <p><strong>OCR:</strong> ${job.auto_ocr_used ? 'Sí' : 'No'}</p>
        <p><strong>Modo:</strong> ${stats.layout_mode || 'layout'}</p>
      </div>`
    : '';
  const errorHtml = job.error ? `<p><strong>Error:</strong> ${job.error}</p>` : '';
  const logs = (job.log || []).map(item => `<li>${item}</li>`).join('');

  jobPanel.classList.remove('muted');
  jobPanel.innerHTML = `
    <div class="status"><span class="dot ${statusClass}"></span>${job.status.toUpperCase()}</div>
    <p><strong>Trabajo:</strong> <span class="code">${job.job_id}</span></p>
    <p><strong>Archivo:</strong> ${job.original_filename}</p>
    <p><strong>Idiomas:</strong> ${job.source_lang.toUpperCase()} → ${job.target_lang.toUpperCase()}</p>
    ${statsHtml}
    ${errorHtml}
    <h3>Registro</h3>
    <ol class="log-list">${logs || '<li>Esperando información…</li>'}</ol>
  `;

  if (job.status === 'completed') {
    downloadPanel.innerHTML = `
      <p class="download-link"><a href="/api/jobs/${job.job_id}/download">Descargar PDF traducido</a></p>
      <p class="note">También queda guardado el HTML reconstruido y los JSON intermedios en la carpeta del trabajo.</p>
    `;
  } else {
    downloadPanel.innerHTML = '';
  }
}

async function pollJob(jobId) {
  const response = await fetch(`/api/jobs/${jobId}`);
  const job = await response.json();
  renderStatus(job);
  if (job.status === 'running' || job.status === 'queued') {
    setTimeout(() => pollJob(jobId), 2500);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(form);
  const source = formData.get('source_lang');
  const target = formData.get('target_lang');
  const validPair = pairs.some(pair => pair.source === source && pair.target === target);
  if (!validPair) {
    jobPanel.classList.remove('muted');
    jobPanel.textContent = 'El par de idiomas seleccionado no está configurado.';
    return;
  }

  jobPanel.classList.remove('muted');
  jobPanel.textContent = 'Subiendo archivo y creando trabajo…';
  downloadPanel.innerHTML = '';

  try {
    const response = await fetch('/api/jobs', {
      method: 'POST',
      body: formData,
    });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.detail || 'No se pudo crear el trabajo.');
    }
    pollJob(payload.job_id);
  } catch (error) {
    jobPanel.textContent = error.message;
  }
});

fillLanguageSelect(sourceSelect, uniqueLanguages('source'), 'es');
syncTargetOptions();
sourceSelect.addEventListener('change', syncTargetOptions);
