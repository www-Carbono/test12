from __future__ import annotations

import base64
import html
import json
import math
import shutil
import statistics
import subprocess
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import fitz
from weasyprint import HTML

from app.config import Settings
from app.services.job_store import JobStore
from app.services.translator import OpusTranslator


@dataclass
class TextBlock:
    page_number: int
    bbox: tuple[float, float, float, float]
    text: str
    original_text: str
    font_size: float
    fitted_font_size: float
    font_family: str
    font_weight: str
    text_align: str
    line_height: float
    color: str
    is_heading: bool


@dataclass
class ImageBlock:
    page_number: int
    bbox: tuple[float, float, float, float]
    rel_path: str
    mime_type: str


@dataclass
class PageLayout:
    page_number: int
    width: float
    height: float
    text_blocks: list[TextBlock]
    image_blocks: list[ImageBlock]


class PDFTranslationPipeline:
    def __init__(
        self,
        settings: Settings | None = None,
        job_store: JobStore | None = None,
        translator: OpusTranslator | None = None,
    ) -> None:
        self.settings = settings or Settings()
        self.job_store = job_store or JobStore()
        self.translator = translator or OpusTranslator(self.settings)

    def run(self, job_id: str, input_pdf: Path, source_lang: str, target_lang: str, force_ocr: bool) -> Path:
        job_dir = self.job_store.job_dir(job_id)
        searchable_pdf = job_dir / "searchable.pdf"
        structured_json = job_dir / "structured.json"
        translated_json = job_dir / "translated.json"
        html_out = job_dir / "translated.html"
        final_pdf = job_dir / "translated.pdf"

        self.job_store.update(job_id, status="running")
        self.job_store.append_log(job_id, "Analizando el PDF de entrada.")

        use_ocr = force_ocr or self._needs_ocr(input_pdf)
        self.job_store.update(job_id, auto_ocr_used=use_ocr)

        working_pdf = input_pdf
        if use_ocr:
            self.job_store.append_log(job_id, "Aplicando OCR con OCRmyPDF/Tesseract.")
            working_pdf = self._run_ocr(input_pdf, searchable_pdf)
        else:
            shutil.copy2(input_pdf, searchable_pdf)
            working_pdf = searchable_pdf
            self.job_store.append_log(job_id, "No se detectó OCR obligatorio; se usa el PDF original.")

        self.job_store.append_log(job_id, "Extrayendo layout, cajas de texto e imágenes con PyMuPDF.")
        pages, stats = self._extract_layout(working_pdf, job_dir)
        structured_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "pages": [self._page_to_dict(page, translated=False) for page in pages],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        self.job_store.update(job_id, stats=stats)

        text_items = [block.text for page in pages for block in page.text_blocks]
        self.job_store.append_log(job_id, f"Traduciendo {len(text_items)} bloques con Marian / OPUS-MT.")
        translated_texts = self.translator.translate_blocks(text_items, source_lang, target_lang)
        self._apply_translations(pages, translated_texts)

        translated_json.write_text(
            json.dumps(
                {
                    "stats": stats,
                    "pages": [self._page_to_dict(page, translated=True) for page in pages],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        self.job_store.append_log(job_id, "Reconstruyendo HTML posicionado con imágenes preservadas.")
        html_string = self._build_positioned_html(pages, source_lang, target_lang, input_pdf.name)
        html_out.write_text(html_string, encoding="utf-8")

        self.job_store.append_log(job_id, "Generando PDF final con WeasyPrint.")
        HTML(string=html_string, base_url=str(job_dir)).write_pdf(str(final_pdf))

        self.job_store.update(
            job_id,
            status="completed",
            paths={
                "original_pdf": str(input_pdf),
                "searchable_pdf": str(searchable_pdf),
                "structured_json": str(structured_json),
                "translated_json": str(translated_json),
                "translated_html": str(html_out),
                "translated_pdf": str(final_pdf),
            },
        )
        self.job_store.append_log(job_id, "Trabajo completado.")
        return final_pdf

    def _needs_ocr(self, input_pdf: Path) -> bool:
        doc = fitz.open(input_pdf)
        total_chars = 0
        sampled_pages = min(len(doc), 5)
        for page_number in range(sampled_pages):
            page = doc.load_page(page_number)
            text = page.get_text("text")
            total_chars += len(text.strip())
        doc.close()
        avg_chars = total_chars // max(sampled_pages, 1)
        return avg_chars < self.settings.auto_ocr_char_threshold

    def _run_ocr(self, input_pdf: Path, output_pdf: Path) -> Path:
        cmd = [
            "ocrmypdf",
            "--skip-text",
            "--optimize",
            "0",
            str(input_pdf),
            str(output_pdf),
        ]
        process = subprocess.run(cmd, capture_output=True, text=True)
        if process.returncode != 0:
            raise RuntimeError(
                "OCRmyPDF falló. "
                f"stdout={process.stdout.strip()} stderr={process.stderr.strip()}"
            )
        return output_pdf

    def _extract_layout(self, pdf_path: Path, job_dir: Path) -> tuple[list[PageLayout], dict]:
        doc = fitz.open(pdf_path)
        images_dir = job_dir / "images"
        images_dir.mkdir(parents=True, exist_ok=True)

        temp_pages: list[dict] = []
        all_font_sizes: list[float] = []
        pages_with_text = 0
        total_images = 0

        for page_index in range(len(doc)):
            page = doc.load_page(page_index)
            page_width = float(page.rect.width)
            page_height = float(page.rect.height)
            page_text_items: list[dict] = []
            page_image_items: list[ImageBlock] = []
            blocks = page.get_text(
                "dict",
                sort=True,
                flags=fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_DEHYPHENATE,
            ).get("blocks", [])

            for block_index, block in enumerate(blocks):
                block_type = block.get("type")
                bbox = self._normalize_bbox(block.get("bbox", (0, 0, 0, 0)), page_width, page_height)
                if block_type == 0:
                    text_payload = self._parse_text_block(block, bbox, page_width)
                    if text_payload is None:
                        continue
                    page_text_items.append(text_payload)
                    all_font_sizes.append(text_payload["font_size"])
                elif block_type == 1:
                    image_item = self._parse_image_block(block, bbox, page_index + 1, block_index + 1, images_dir)
                    if image_item is not None:
                        page_image_items.append(image_item)
                        total_images += 1

            if page_text_items:
                pages_with_text += 1

            temp_pages.append(
                {
                    "page_number": page_index + 1,
                    "width": page_width,
                    "height": page_height,
                    "text_blocks": page_text_items,
                    "image_blocks": page_image_items,
                }
            )

        doc.close()

        body_size = statistics.median(all_font_sizes) if all_font_sizes else 10.5
        pages: list[PageLayout] = []
        text_block_count = 0

        for item in temp_pages:
            page_width = item["width"]
            page_height = item["height"]
            text_blocks: list[TextBlock] = []
            for raw in item["text_blocks"]:
                is_heading = raw["font_size"] >= body_size * 1.18 and len(raw["text"]) < 220
                text_blocks.append(
                    TextBlock(
                        page_number=item["page_number"],
                        bbox=raw["bbox"],
                        text=raw["text"],
                        original_text=raw["text"],
                        font_size=raw["font_size"],
                        fitted_font_size=raw["font_size"],
                        font_family=self._map_font_family(raw["font_name"]),
                        font_weight=raw["font_weight"],
                        text_align=self._guess_text_align(raw["bbox"], page_width, is_heading),
                        line_height=raw["line_height"],
                        color=raw["color"],
                        is_heading=is_heading,
                    )
                )
                text_block_count += 1

            pages.append(
                PageLayout(
                    page_number=item["page_number"],
                    width=page_width,
                    height=page_height,
                    text_blocks=text_blocks,
                    image_blocks=item["image_blocks"],
                )
            )

        stats = {
            "pages": len(pages),
            "pages_with_text": pages_with_text,
            "text_blocks": text_block_count,
            "image_blocks": total_images,
            "body_font_size": round(body_size, 2),
            "layout_mode": "absolute-positioned-html",
        }
        return pages, stats

    def _parse_text_block(
        self,
        block: dict,
        bbox: tuple[float, float, float, float],
        page_width: float,
    ) -> dict | None:
        lines = block.get("lines", [])
        rendered_lines: list[str] = []
        sizes: list[float] = []
        fonts: list[str] = []
        weights: list[str] = []
        colors: list[str] = []

        for line in lines:
            spans = line.get("spans", [])
            line_parts: list[str] = []
            for span in spans:
                span_text = span.get("text", "")
                if not span_text:
                    continue
                line_parts.append(span_text)
                sizes.append(float(span.get("size", 11.0)))
                font_name = str(span.get("font", ""))
                if font_name:
                    fonts.append(font_name)
                    weights.append("700" if "bold" in font_name.lower() else "400")
                colors.append(self._color_to_hex(span.get("color", 0)))
            joined = "".join(line_parts).rstrip()
            if joined.strip():
                rendered_lines.append(joined)

        text = "\n".join(rendered_lines).strip()
        if not text:
            return None

        font_name = Counter(fonts).most_common(1)[0][0] if fonts else "sans-serif"
        font_weight = Counter(weights).most_common(1)[0][0] if weights else "400"
        color = Counter(colors).most_common(1)[0][0] if colors else "#111111"
        font_size = statistics.median(sizes) if sizes else 11.0
        line_height = self._estimate_line_height(block, font_size)

        return {
            "bbox": bbox,
            "text": text,
            "font_size": float(font_size),
            "font_name": font_name,
            "font_weight": font_weight,
            "color": color,
            "line_height": line_height,
        }

    def _parse_image_block(
        self,
        block: dict,
        bbox: tuple[float, float, float, float],
        page_number: int,
        block_number: int,
        images_dir: Path,
    ) -> ImageBlock | None:
        image_bytes = block.get("image")
        if not image_bytes:
            return None
        ext = str(block.get("ext") or "png").lower()
        if ext == "jpeg":
            ext = "jpg"
        filename = f"page_{page_number:04d}_img_{block_number:03d}.{ext}"
        output_path = images_dir / filename
        if isinstance(image_bytes, bytes):
            output_path.write_bytes(image_bytes)
        else:
            try:
                output_path.write_bytes(base64.b64decode(image_bytes))
            except Exception:
                return None
        mime = {
            "png": "image/png",
            "jpg": "image/jpeg",
            "jpeg": "image/jpeg",
            "webp": "image/webp",
        }.get(ext, "image/png")
        rel_path = output_path.relative_to(images_dir.parent).as_posix()
        return ImageBlock(page_number=page_number, bbox=bbox, rel_path=rel_path, mime_type=mime)

    def _apply_translations(self, pages: list[PageLayout], translated_texts: list[str]) -> None:
        index = 0
        for page in pages:
            for block in page.text_blocks:
                translated_text = translated_texts[index] if index < len(translated_texts) else block.text
                index += 1
                block.text = translated_text
                block.fitted_font_size = self._fit_font_size(
                    original=block.original_text,
                    translated=translated_text,
                    bbox=block.bbox,
                    base_font_size=block.font_size,
                    line_height=block.line_height,
                )

    def _fit_font_size(
        self,
        original: str,
        translated: str,
        bbox: tuple[float, float, float, float],
        base_font_size: float,
        line_height: float,
    ) -> float:
        width = max(bbox[2] - bbox[0], 1.0)
        height = max(bbox[3] - bbox[1], 1.0)
        orig_chars = max(len(original.strip()), 1)
        trans_chars = max(len(translated.strip()), 1)
        ratio = trans_chars / orig_chars
        scale = 1.0
        if ratio > 1.12:
            scale /= min(pow(ratio, 0.32), 1.55)
        approx_lines = max(original.count("\n") + 1, 1)
        avg_char_width = max(base_font_size * 0.52, 3.5)
        approx_capacity = max(int((width / avg_char_width) * approx_lines), 1)
        if trans_chars > approx_capacity:
            overflow_ratio = trans_chars / approx_capacity
            scale /= min(pow(overflow_ratio, 0.28), 1.45)
        if height < base_font_size * line_height * 1.2:
            scale *= 0.92
        return max(self.settings.min_font_size, round(base_font_size * scale, 2))

    def _build_positioned_html(
        self,
        pages: list[PageLayout],
        source_lang: str,
        target_lang: str,
        original_filename: str,
    ) -> str:
        size_rules: list[str] = []
        body_pages: list[str] = []
        for page in pages:
            page_name = f"page_{page.page_number}"
            size_rules.append(
                f"@page {page_name} {{ size: {page.width:.2f}pt {page.height:.2f}pt; margin: 0; }}"
            )
            image_html = []
            for image in page.image_blocks:
                image_html.append(
                    "<img class=\"img-layer\" src=\"{src}\" alt=\"\" style=\"left:{left:.2f}pt;top:{top:.2f}pt;width:{width:.2f}pt;height:{height:.2f}pt;\">".format(
                        src=html.escape(image.rel_path),
                        left=image.bbox[0],
                        top=image.bbox[1],
                        width=max(image.bbox[2] - image.bbox[0], 1),
                        height=max(image.bbox[3] - image.bbox[1], 1),
                    )
                )
            text_html = []
            for block in page.text_blocks:
                safe_text = html.escape(block.text).replace("\n", "<br>")
                width = max(block.bbox[2] - block.bbox[0], 1)
                height = max(block.bbox[3] - block.bbox[1], 1)
                css_class = "text-layer heading" if block.is_heading else "text-layer"
                text_html.append(
                    (
                        "<div class=\"{css_class}\" style=\"left:{left:.2f}pt;top:{top:.2f}pt;width:{width:.2f}pt;"
                        "min-height:{height:.2f}pt;font-size:{font_size:.2f}pt;line-height:{line_height:.3f};"
                        "font-family:{font_family};font-weight:{font_weight};text-align:{text_align};color:{color};\">{text}</div>"
                    ).format(
                        css_class=css_class,
                        left=block.bbox[0],
                        top=block.bbox[1],
                        width=width,
                        height=height,
                        font_size=block.fitted_font_size,
                        line_height=block.line_height,
                        font_family=block.font_family,
                        font_weight=block.font_weight,
                        text_align=block.text_align,
                        color=block.color,
                        text=safe_text,
                    )
                )

            body_pages.append(
                f'''<section class="page-sheet" style="page:{page_name};width:{page.width:.2f}pt;height:{page.height:.2f}pt;">
<div class="page-canvas" style="width:{page.width:.2f}pt;height:{page.height:.2f}pt;">
{''.join(image_html)}
{''.join(text_html)}
</div>
</section>'''
            )

        return f"""
<!doctype html>
<html lang=\"es\">
<head>
  <meta charset=\"utf-8\">
  <title>PDF traducido</title>
  <style>
    {' '.join(size_rules)}
    * {{ box-sizing: border-box; }}
    html, body {{ margin: 0; padding: 0; background: #ffffff; color: #111827; }}
    body {{ font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }}
    .page-sheet {{ page-break-after: always; break-after: page; position: relative; background: #fff; overflow: hidden; }}
    .page-sheet:last-child {{ page-break-after: auto; break-after: auto; }}
    .page-canvas {{ position: relative; overflow: hidden; background: #fff; }}
    .img-layer {{ position: absolute; display: block; object-fit: contain; }}
    .text-layer {{
      position: absolute;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      word-break: break-word;
      hyphens: auto;
      margin: 0;
      padding: 0;
    }}
    .text-layer.heading {{ letter-spacing: 0.01em; }}
  </style>
</head>
<body>
  {''.join(body_pages)}
</body>
</html>
""".strip()

    def _page_to_dict(self, page: PageLayout, translated: bool) -> dict:
        return {
            "page_number": page.page_number,
            "width": page.width,
            "height": page.height,
            "text_blocks": [
                {
                    "bbox": list(block.bbox),
                    "text": block.text,
                    "original_text": block.original_text,
                    "font_size": block.font_size,
                    "fitted_font_size": block.fitted_font_size,
                    "font_family": block.font_family,
                    "font_weight": block.font_weight,
                    "text_align": block.text_align,
                    "line_height": block.line_height,
                    "color": block.color,
                    "is_heading": block.is_heading,
                    "translated": translated,
                }
                for block in page.text_blocks
            ],
            "image_blocks": [
                {
                    "bbox": list(image.bbox),
                    "rel_path": image.rel_path,
                    "mime_type": image.mime_type,
                }
                for image in page.image_blocks
            ],
        }

    def _normalize_bbox(
        self,
        bbox: tuple[float, float, float, float] | list[float],
        page_width: float,
        page_height: float,
    ) -> tuple[float, float, float, float]:
        x0, y0, x1, y1 = [float(value) for value in bbox]
        x0 = max(0.0, min(x0, page_width))
        x1 = max(0.0, min(x1, page_width))
        y0 = max(0.0, min(y0, page_height))
        y1 = max(0.0, min(y1, page_height))
        return (x0, y0, x1, y1)

    def _estimate_line_height(self, block: dict, font_size: float) -> float:
        bbox = block.get("bbox", (0, 0, 0, 0))
        height = max(float(bbox[3]) - float(bbox[1]), font_size)
        line_count = max(len(block.get("lines", [])), 1)
        raw = height / max(font_size * line_count, 1.0)
        return round(min(max(raw, 1.05), 1.45), 3)

    def _guess_text_align(self, bbox: tuple[float, float, float, float], page_width: float, is_heading: bool) -> str:
        x0, _, x1, _ = bbox
        width = x1 - x0
        center = (x0 + x1) / 2
        if is_heading and abs(center - (page_width / 2)) < page_width * 0.08 and width < page_width * 0.75:
            return "center"
        if width > page_width * 0.6:
            return "justify"
        return "left"

    def _map_font_family(self, font_name: str) -> str:
        lowered = (font_name or "").lower()
        if any(token in lowered for token in ("courier", "mono", "console")):
            return "monospace"
        if any(token in lowered for token in ("times", "georgia", "serif", "garamond")):
            return "serif"
        return "sans-serif"

    def _color_to_hex(self, color_value: int | str | None) -> str:
        if color_value is None:
            return "#111111"
        if isinstance(color_value, str):
            color_value = color_value.strip()
            if color_value.startswith("#"):
                return color_value
            try:
                color_value = int(color_value)
            except ValueError:
                return "#111111"
        try:
            value = int(color_value)
        except Exception:
            return "#111111"
        if value < 0:
            value = 0
        if value <= 0xFFFFFF:
            return f"#{value:06x}"
        red = (value >> 16) & 255
        green = (value >> 8) & 255
        blue = value & 255
        return f"#{red:02x}{green:02x}{blue:02x}"
