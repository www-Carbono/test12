# PDF Translator Pipeline (Ubuntu, layout-preserving v2)

Proyecto completo para traducir PDF con este pipeline:

**PyMuPDF + OCRmyPDF/Tesseract + Marian / OPUS-MT por par de idiomas + WeasyPrint**

Esta versión mejora la primera entrega en un punto clave: ya no reconstruye el documento como texto corrido, sino que intenta **mantener mejor el layout original** usando bloques posicionados e imágenes extraídas del PDF.

## Qué hace esta versión

1. Recibe un PDF desde la web.
2. Detecta si hace falta OCR o lo fuerza si lo marcas.
3. Si hace falta OCR, genera una versión searchable con `ocrmypdf`.
4. Extrae con **PyMuPDF**:
   - tamaño real de cada página,
   - bloques de texto con coordenadas,
   - imágenes raster con sus coordenadas.
5. Traduce cada bloque con **Marian / OPUS-MT**.
6. Ajusta ligeramente el tamaño de letra cuando el texto traducido crece mucho.
7. Reconstruye un **HTML absoluto** por página.
8. Genera el PDF final con **WeasyPrint**.

## Qué mejora respecto a la versión simple

- Respeta mucho mejor columnas, secciones y saltos visuales.
- Conserva imágenes raster del original.
- Mantiene tamaño de página y posición aproximada de los bloques.
- Produce un PDF más parecido al original.

## Limitaciones que siguen existiendo

- No es clonación pixel-perfect.
- Algunos PDFs con tablas muy complejas, textos rotados, fondos vectoriales o diagramas no raster pueden seguir degradándose.
- Si la traducción se alarga mucho, ciertos bloques pueden reducir su fuente para entrar en caja.

## Estructura

```text
pdf_translator_project_ubuntu_v2/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── templates/index.html
│   │   ├── static/css/styles.css
│   │   ├── static/js/app.js
│   │   └── services/
│   │       ├── job_store.py
│   │       ├── pdf_pipeline.py
│   │       └── translator.py
│   └── data/
├── config/
│   └── custom_models.json
├── scripts/
│   ├── install_ubuntu.sh
│   ├── prefetch_models.py
│   └── run.sh
├── requirements.txt
└── .env.example
```

## Instalación rápida en Ubuntu

### 1) Instala el proyecto

```bash
cd pdf_translator_project_ubuntu_v2
bash scripts/install_ubuntu.sh
```

### 2) Activa el entorno virtual

```bash
source .venv/bin/activate
```

### 3) Copia la configuración base

```bash
cp .env.example .env
```

### 4) Arranca la aplicación

```bash
bash scripts/run.sh
```

### 5) Abre la web

- Local: `http://localhost:8000`
- Remoto: `http://IP_DEL_SERVIDOR:8000`

## Precargar modelos

La primera traducción descarga el modelo automáticamente. Si prefieres dejarlo listo antes:

```bash
source .venv/bin/activate
python scripts/prefetch_models.py
```

## Configuración útil

Variables disponibles en `.env`:

```env
APP_HOST=0.0.0.0
APP_PORT=8000
MAX_UPLOAD_MB=80
AUTO_OCR_CHAR_THRESHOLD=60
TRANSLATION_BATCH_SIZE=8
TRANSLATION_CHAR_CHUNK=450
TRANSLATION_MAX_NEW_TOKENS=512
LAYOUT_MIN_FONT_SIZE=6.5
MODEL_MAP_FILE=config/custom_models.json
HF_HOME=.cache/huggingface
```

### `LAYOUT_MIN_FONT_SIZE`

Es el tamaño mínimo de fuente que el reconstructor usará cuando el texto traducido sea bastante más largo que el original.

## Cambiar o ampliar pares de idiomas

Edita `config/custom_models.json`.

Ejemplo:

```json
[
  {
    "source": "es",
    "target": "en",
    "model_id": "Helsinki-NLP/opus-mt-es-en"
  },
  {
    "source": "en",
    "target": "fr",
    "model_id": "Helsinki-NLP/opus-mt-en-fr"
  }
]
```

Después reinicia la app.

## Dependencias del sistema

El script instala:

- Python 3 y venv
- `tesseract-ocr`
- `ghostscript`
- `qpdf`
- `pngquant`
- librerías de Cairo/Pango para WeasyPrint
- fuentes base (`fonts-dejavu-core`)

## Salidas generadas por cada trabajo

Cada trabajo queda dentro de:

```text
backend/data/jobs/<job_id>/
```

Y guarda:

- `searchable.pdf`
- `structured.json`
- `translated.json`
- `translated.html`
- `translated.pdf`
- carpeta `images/` con las imágenes extraídas del PDF

## Recomendaciones prácticas

- Para PDFs escaneados, activa **Forzar OCR** si ves que faltan bloques.
- Para manuales o catálogos con muchas imágenes, esta versión da bastante mejor resultado que la anterior.
- Para traducción técnica muy sensible al layout, revisa también el `translated.html`, porque te sirve para depurar mejor que el PDF final.

## Siguientes mejoras posibles

- selector de idioma OCR desde la UI
- extracción de tablas más avanzada
- preservación de fondos vectoriales
- colas con Redis/Celery
- autenticación y control de usuarios
